using héritagePokémon;
using System.Windows.Forms;
namespace PokemonTCG.WinForms
{
    public partial class Form1 : Form
    {
        private readonly Joueur _joueur;
        private readonly Joueur _adversaire;
        public Form1(Joueur joueur, Joueur adversaire)
        {
            InitializeComponent();
            // TODO : 1. mémoriser joueur et adversaire dans les attributs privés
            // 2. afficher le nom du joueur dans le texte de grpJoueur
            // 3. définir DisplayMember = "Nom" sur lstMain, lstBanc et
            // cmbAttaques (chaque liste affichera la propriété Nom des objets)
            // 4. appeler ActualiserAffichage()
            this._joueur = joueur;
            this._adversaire = adversaire;
            grpJoueur.Text = this._joueur.Nom;
            lstMain.DisplayMember = "Nom";
            lstBanc.DisplayMember = "Nom";
            cmbAttaques.DisplayMember = "Nom";
            ActualiserAffichage();
        }
        private void ActualiserAffichage()
        {
            // TODO : 1. lblDeck : "Deck : n carte(s)"
            // 2. lstMain : vider la liste puis y ajouter les cartes de la main
            // (Items.AddRange avec Main.ToArray())
            // 3. lstBanc : même principe avec le banc
            // 4. lblActif : Decrire() du Pokémon actif, ou "Aucun Pokémon actif"
            // 5. lblEnergies : "Énergies : n" (0 sans Pokémon actif)
            // 6. cmbAttaques : vider puis y ajouter les attaques du Pokémon actif
            // 7. lblActifAdversaire : comme lblActif, pour l'adversaire
            lblDeck.Text = $"Deck : {_joueur.Deck.Count} carte(s)";
            lstMain.Items.Clear();
            lstMain.Items.AddRange(this._joueur.Main.ToArray());
            lstBanc.Items.Clear();
            lstBanc.Items.AddRange(this._joueur.Banc.ToArray());
            cmbAttaques.Items.Clear();
            if (this._joueur.PokemonActif == null)
            {
                lblActif.Text = "aucun Pokémon actif";
                lblEnergies.Text = "énergies : 0";
            } else
            {
                lblActif.Text = this._joueur.PokemonActif.Decrire();
                lblEnergies.Text = $"énergie : {_joueur.PokemonActif.EnergiesAttachees} ";
                cmbAttaques.Items.AddRange(this._joueur.PokemonActif.Attaques.ToArray());

            }
            if (_adversaire.PokemonActif == null)
            {
                lblActifAdversaire.Text = "Aucun Pokémon actif";
            }
            else
            {
                lblActifAdversaire.Text = this._adversaire.PokemonActif.Decrire();
            }

        }
        private void AfficherMessage(string texte, bool erreur)
        {
            // TODO : afficher le texte dans lblMessage, en rouge si erreur,
            // en vert sinon
            lblMessage.Text = texte;
            if (erreur) 
            {
                lblMessage.ForeColor = Color.Red;
            } else
            {
                lblMessage.ForeColor = Color.Green;
            }
        }
        private void btnPiocher_Click(object sender, EventArgs e)
        {
            // TODO : 1. dans un try, appeler _joueur.Piocher() et afficher un
            // message de succès contenant le nom de la carte piochée
            // 2. attraper InvalidOperationException : afficher ex.Message
            // en erreur
            // 3. actualiser l'affichage
            try
            {
                Carte r = this._joueur.Piocher();
                AfficherMessage($"{r.Nom}", false);
            } catch (InvalidOperationException ex)
            {
                AfficherMessage(ex.Message, true);
            }
            ActualiserAffichage();
        }
        private void btnJouerCarte_Click(object sender, EventArgs e)
        {
            // TODO : 1. si lstMain.SelectedItem est null : message d'erreur
            // (ex : "Sélectionnez une carte.") puis return
            // 2. récupérer la carte sélectionnée (conversion en Carte)
            // 3. dans un try, appeler _joueur.JouerCarte(carte) et afficher
            // un message de succès ; attraper InvalidOperationException
            // 4. actualiser l'affichage
            if (lstMain.SelectedItem == null)
            {
                AfficherMessage("sélectionnez une carte", true);
                return;
                
            } else
            {
                Carte carte = (Carte)lstMain.SelectedItem;
                try
                {
                    this._joueur.JouerCarte(carte);
                    AfficherMessage($"la carte: {carte} est jouer", false);
                } catch(InvalidOperationException ex)
                {
                    ActualiserAffichage();
                }
            }
        }
        private void btnAttaquer_Click(object sender, EventArgs e)
        {
            // TODO : 1. si cmbAttaques.SelectedItem est null : message d'erreur
            // puis return
            // 2. récupérer l'attaque sélectionnée (conversion en Attaque)
            // 3. dans un try, appeler _joueur.Attaquer(attaque, _adversaire)
            // et afficher les dégâts infligés ; si le Pokémon adverse
            // est K.O., l'indiquer dans le message
            // 4. attraper InvalidOperationException et ArgumentException
            // 5. actualiser l'affichage
            if (cmbAttaques.SelectedItem == null)
            {
                AfficherMessage("sélectionnez une attaque", true);
                return;
            } else
            {
                Attaque attaque = (Attaque)cmbAttaques.SelectedItem;
                try
                {
                    this._joueur.Attaquer(attaque, _adversaire);
                    AfficherMessage($"dégâts infligés : {this._adversaire.PokemonActif.PointsDeVie}", false);
                    if (this._adversaire.PokemonActif.EstKO)
                    {
                        AfficherMessage($"pokemon KO, dégâts infligés : {this._adversaire.PokemonActif.PointsDeVie}", false);
                    }
                } catch(InvalidOperationException ex)
                {
                    ActualiserAffichage();
                } catch(ArgumentException ex) 
                {
                    ActualiserAffichage(); 
                }
            }
        }
        private void btnPasserTour_Click(object sender, EventArgs e)
        {
            // TODO : 1. appeler _joueur.PasserSonTour()
            // 2. afficher le message "Tour terminé."
            // 3. actualiser l'affichage
            this._joueur.PasserSonTour();
            AfficherMessage("tour terminé", false);
            ActualiserAffichage();
        }

    }
}
