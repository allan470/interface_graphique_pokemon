﻿namespace PokemonTCG.WinForms
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grpJoueur = new GroupBox();
            btnPiocher = new Button();
            btnJoueurCarte = new Button();
            btnPasserTour = new Button();
            btnAttaquer = new Button();
            cmbAttaques = new ComboBox();
            lblEnergies = new Label();
            lblActif = new Label();
            lstBanc = new ListBox();
            lstMain = new ListBox();
            lblDeck = new Label();
            grpAdversaire = new GroupBox();
            lblActifAdversaire = new Label();
            lblMessage = new Label();
            grpJoueur.SuspendLayout();
            grpAdversaire.SuspendLayout();
            SuspendLayout();
            // 
            // grpJoueur
            // 
            grpJoueur.Controls.Add(btnPiocher);
            grpJoueur.Controls.Add(btnJoueurCarte);
            grpJoueur.Controls.Add(btnPasserTour);
            grpJoueur.Controls.Add(btnAttaquer);
            grpJoueur.Controls.Add(cmbAttaques);
            grpJoueur.Controls.Add(lblEnergies);
            grpJoueur.Controls.Add(lblActif);
            grpJoueur.Controls.Add(lstBanc);
            grpJoueur.Controls.Add(lstMain);
            grpJoueur.Controls.Add(lblDeck);
            grpJoueur.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            grpJoueur.ForeColor = Color.CornflowerBlue;
            grpJoueur.Location = new Point(40, 28);
            grpJoueur.Name = "grpJoueur";
            grpJoueur.Size = new Size(470, 344);
            grpJoueur.TabIndex = 0;
            grpJoueur.TabStop = false;
            grpJoueur.Text = "nom du joueur";
            // 
            // btnPiocher
            // 
            btnPiocher.Font = new Font("Segoe UI", 9F);
            btnPiocher.ForeColor = SystemColors.WindowText;
            btnPiocher.Location = new Point(28, 296);
            btnPiocher.Name = "btnPiocher";
            btnPiocher.Size = new Size(118, 31);
            btnPiocher.TabIndex = 9;
            btnPiocher.Text = "btnPiocher";
            btnPiocher.UseVisualStyleBackColor = true;
            // 
            // btnJoueurCarte
            // 
            btnJoueurCarte.Font = new Font("Segoe UI", 9F);
            btnJoueurCarte.ForeColor = SystemColors.WindowText;
            btnJoueurCarte.Location = new Point(165, 296);
            btnJoueurCarte.Name = "btnJoueurCarte";
            btnJoueurCarte.Size = new Size(118, 31);
            btnJoueurCarte.TabIndex = 8;
            btnJoueurCarte.Text = "btnJoueurCarte";
            btnJoueurCarte.UseVisualStyleBackColor = true;
            // 
            // btnPasserTour
            // 
            btnPasserTour.Font = new Font("Segoe UI", 9F);
            btnPasserTour.ForeColor = SystemColors.WindowText;
            btnPasserTour.Location = new Point(320, 296);
            btnPasserTour.Name = "btnPasserTour";
            btnPasserTour.Size = new Size(118, 31);
            btnPasserTour.TabIndex = 7;
            btnPasserTour.Text = "btnPasserTour";
            btnPasserTour.UseVisualStyleBackColor = true;
            // 
            // btnAttaquer
            // 
            btnAttaquer.Font = new Font("Segoe UI", 9F);
            btnAttaquer.ForeColor = SystemColors.WindowText;
            btnAttaquer.Location = new Point(253, 245);
            btnAttaquer.Name = "btnAttaquer";
            btnAttaquer.Size = new Size(180, 36);
            btnAttaquer.TabIndex = 6;
            btnAttaquer.Text = "btnAttaquer";
            btnAttaquer.UseVisualStyleBackColor = true;
            // 
            // cmbAttaques
            // 
            cmbAttaques.Font = new Font("Segoe UI", 9F);
            cmbAttaques.FormattingEnabled = true;
            cmbAttaques.Location = new Point(28, 245);
            cmbAttaques.Name = "cmbAttaques";
            cmbAttaques.Size = new Size(192, 23);
            cmbAttaques.TabIndex = 5;
            cmbAttaques.Text = "cmbAttaques";
            // 
            // lblEnergies
            // 
            lblEnergies.AutoSize = true;
            lblEnergies.BackColor = Color.BlanchedAlmond;
            lblEnergies.BorderStyle = BorderStyle.FixedSingle;
            lblEnergies.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblEnergies.ForeColor = SystemColors.WindowText;
            lblEnergies.Location = new Point(367, 206);
            lblEnergies.Name = "lblEnergies";
            lblEnergies.Size = new Size(66, 17);
            lblEnergies.TabIndex = 4;
            lblEnergies.Text = "lblEnergies";
            // 
            // lblActif
            // 
            lblActif.AutoSize = true;
            lblActif.BackColor = Color.PapayaWhip;
            lblActif.BorderStyle = BorderStyle.FixedSingle;
            lblActif.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblActif.ForeColor = SystemColors.WindowText;
            lblActif.Location = new Point(28, 206);
            lblActif.Name = "lblActif";
            lblActif.Size = new Size(47, 17);
            lblActif.TabIndex = 3;
            lblActif.Text = "lblActif";
            // 
            // lstBanc
            // 
            lstBanc.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lstBanc.FormattingEnabled = true;
            lstBanc.Location = new Point(253, 70);
            lstBanc.Name = "lstBanc";
            lstBanc.Size = new Size(180, 124);
            lstBanc.TabIndex = 2;
            // 
            // lstMain
            // 
            lstMain.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lstMain.FormattingEnabled = true;
            lstMain.Location = new Point(28, 70);
            lstMain.Name = "lstMain";
            lstMain.Size = new Size(192, 124);
            lstMain.TabIndex = 1;
            // 
            // lblDeck
            // 
            lblDeck.AutoSize = true;
            lblDeck.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDeck.ForeColor = SystemColors.WindowText;
            lblDeck.Location = new Point(28, 38);
            lblDeck.Name = "lblDeck";
            lblDeck.Size = new Size(42, 15);
            lblDeck.TabIndex = 0;
            lblDeck.Text = "Deck : ";
            // 
            // grpAdversaire
            // 
            grpAdversaire.Controls.Add(lblActifAdversaire);
            grpAdversaire.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            grpAdversaire.ForeColor = Color.DarkOrange;
            grpAdversaire.Location = new Point(578, 37);
            grpAdversaire.Name = "grpAdversaire";
            grpAdversaire.Size = new Size(190, 327);
            grpAdversaire.TabIndex = 1;
            grpAdversaire.TabStop = false;
            grpAdversaire.Text = "grpAdversaire";
            // 
            // lblActifAdversaire
            // 
            lblActifAdversaire.AutoSize = true;
            lblActifAdversaire.BackColor = Color.BlanchedAlmond;
            lblActifAdversaire.Font = new Font("Segoe UI", 9F);
            lblActifAdversaire.ForeColor = SystemColors.WindowText;
            lblActifAdversaire.Location = new Point(27, 55);
            lblActifAdversaire.Name = "lblActifAdversaire";
            lblActifAdversaire.Size = new Size(100, 15);
            lblActifAdversaire.TabIndex = 0;
            lblActifAdversaire.Text = "lblActifAdversaire";
            // 
            // lblMessage
            // 
            lblMessage.AutoSize = true;
            lblMessage.Location = new Point(165, 407);
            lblMessage.Name = "lblMessage";
            lblMessage.Size = new Size(66, 15);
            lblMessage.TabIndex = 2;
            lblMessage.Text = "lblMessage";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblMessage);
            Controls.Add(grpAdversaire);
            Controls.Add(grpJoueur);
            Name = "Form1";
            Text = "Form1";
            grpJoueur.ResumeLayout(false);
            grpJoueur.PerformLayout();
            grpAdversaire.ResumeLayout(false);
            grpAdversaire.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox grpJoueur;
        private GroupBox grpAdversaire;
        private ListBox lstMain;
        private Label lblDeck;
        private ListBox lstBanc;
        private Label lblActif;
        private Label lblEnergies;
        private ComboBox cmbAttaques;
        private Button btnPiocher;
        private Button btnJoueurCarte;
        private Button btnPasserTour;
        private Button btnAttaquer;
        private Label lblActifAdversaire;
        private Label lblMessage;
    }
}
