using héritagePokémon;
namespace PokemonTCG.WinForms
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            ApplicationConfiguration.Initialize(); // .NET 6 ou supérieur
            // TODO : 1. créer un deck pour le joueur : au moins 1 CartePokemon avec une
            // Attaque (ajoutée à sa liste Attaques) et 4 CarteEnergie
            // 2. créer un deck pour l'adversaire avec au moins 1 CartePokemon
            // 3. créer les deux Joueur
            // 4. l'adversaire pioche et joue son Pokémon (il doit avoir un
            // Pokémon actif dès le début de la partie)
            // 5. remplacer la ligne ci-dessous par
            // Application.Run(new FrmPartie(joueur, adversaire))
            List<Carte> Deck = new List<Carte>();
            CartePokemon pikachu = new CartePokemon("pikachu","souris électrique", Rarete.Commune, 60, TypePokemon.Electrik);
            Attaque attaque = new Attaque("éclair", 20, 1);
            pikachu.Attaques.Add(attaque);
            CarteEnergie carte1 = new CarteEnergie("Énergie Électrik", TypePokemon.Electrik);
            CarteEnergie carte2 = new CarteEnergie("Énergie Électrik", TypePokemon.Electrik);
            CarteEnergie carte3 = new CarteEnergie("Énergie Électrik", TypePokemon.Electrik);
            CarteEnergie carte4 = new CarteEnergie("Énergie Électrik", TypePokemon.Electrik);
            Deck.Add(pikachu);
            Deck.Add(carte1);
            Deck.Add(carte2);
            Deck.Add(carte3);
            Deck.Add(carte4);
            Joueur j1 = new Joueur("sacha", Deck);

            List<Carte> Deck2 = new List<Carte>();
            CartePokemon salameche = new CartePokemon("salameche", "lézard de feu", Rarete.Commune, 70, TypePokemon.Feu);
            Attaque attaque2 = new Attaque("", 20, 1);
            Deck2.Add(salameche);
            Joueur j2 = new Joueur("team rocket", Deck2);
            j2.Piocher();
            j2.JouerCarte(salameche);
            Application.Run(new Form1(j1, j2));
        }
    }
}